THIS IS THE READ FILE FOR ASSIGNMENT 2 FOR COMP2404
——————————————————————————
Submitted by:

Huzaifa Asif - 100921147
Ali Selcuk - 100954050
——————————————————————————

Compiling Instructions:

unzip assignment2.zip
g++ -g -Wall *.cpp *.hpp
./a.out

To execute scriptfile in terminal type “.read2” (it will run the scriptfile2.txt file)

NOTE: do not write .read //it won’t work 
	.quit does not work

———————————————————————————

The file comes with a script file (i.e “.read2” runs “scriptfile2.txt”) that adds the collections of songs, recordings, tracks, playlists, users from the database to application and deletes some of them from the application as well.

The name of the script file is “scriptfile2.txt”

