THIS IS THE READ FILE FOR ASSIGNMENT 4 FOR COMP2404
——————————————————————————
Submitted by:

Huzaifa Asif - 100921147
Ali Selcuk - 100954050
——————————————————————————

Compiling Instructions:

unzip assignment4.zip
g++ -g -Wall *.cpp *.hpp
./a.out

To execute testing scriptfile in terminal please type “.read2” (it will run the hahaha.txt file)

NOTE: do not write .read //it won’t work 
	.quit does not work

———————————————————————————

The file comes with a script file (i.e “.read2” runs “hahaha.txt”) that is used for testing for this assignment.

The name of the script file is “hahaha.txt”

